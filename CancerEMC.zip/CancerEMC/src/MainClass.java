import weka.classifiers.meta.Bagging;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.attribute.Discretize;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;
import weka.classifiers.*;
import weka.classifiers.bayes.AODE;

public class MainClass{
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Welcome to CancerEMC\n");
		
		Instances dataset= new Instances(new BufferedReader(new FileReader("Sub-dataset1 (SD1).arff")));
		System.out.println(dataset.toSummaryString());
		System.out.println("For Dataset SD1");
		cancerEMC(dataset);
		Instances dataset2= new Instances(new BufferedReader(new FileReader("Sub-dataset2 (SD2).arff")));
		System.out.println(dataset2.toSummaryString());
		System.out.println("For Dataset SD2");
		cancerEMC(dataset2);
		
		Instances dataset3= new Instances(new BufferedReader(new FileReader("Sub-dataset3 (SD3).arff")));
		System.out.println(dataset3.toSummaryString());
		System.out.println("For Dataset SD3");
		cancerEMC(dataset3);
		Instances dataset4= new Instances(new BufferedReader(new FileReader("Sub-dataset4 (SD4).arff")));
		System.out.println(dataset4.toSummaryString());
		System.out.println("For Dataset SD4");
		cancerEMC(dataset4);
		
	}
	public static void cancerEMC(Instances dataset) throws Exception {
		dataset.setClassIndex(dataset.numAttributes()-1);
		int n=dataset.numInstances();
		String s=String.valueOf(n);
		int a=dataset.numAttributes()-2;
		String e=String.valueOf(a);
		
		String[] options=new String[2];
		options[0]="-B"; options[1]=s;
		options[0]="-R"; options[1]="1-"+e;
		Discretize discretize=new Discretize();
		discretize.setOptions(options);
		discretize.setInputFormat(dataset);
		Instances newdata=Filter.useFilter(dataset, discretize);
		
		Bagging b=new Bagging();
		b.setClassifier(new AODE());
		b.setNumIterations(15);
		//b.buildClassifier(dataset);
		
		Evaluation evl=new Evaluation(newdata);
		Random rand=new Random(1);
		int folds=10;
		evl.crossValidateModel(b, newdata, folds, rand);
		//System.out.println("AUC="+evl.areaUnderROC(newdata.classIndex()));
		
		System.out.println(evl.toSummaryString());
		System.out.println(evl.toMatrixString());
		System.out.println(evl.getMetricsToDisplay());
		System.out.println(evl.toClassDetailsString(""));
		
		/*
		for (int i = 0; i < newdata.numInstances(); i++) {
			Instance ni=newdata.instance(i);
			b.classifyInstance(ni);
		}
		*/
	}

}

